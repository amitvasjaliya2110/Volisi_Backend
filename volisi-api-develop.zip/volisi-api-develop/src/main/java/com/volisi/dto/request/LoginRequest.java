package com.volisi.dto.request;

public record LoginRequest(String username, String password) {}
