package com.volisi.dto.response;

public record AnswerOptionResponse(Long id, String name) {}
