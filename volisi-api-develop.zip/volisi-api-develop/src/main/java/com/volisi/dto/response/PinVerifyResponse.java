package com.volisi.dto.response;

public record PinVerifyResponse(Long playerQuizId) {}
