package com.volisi.dto.response;

public record PointconfigResponce(String name, String description) {}
