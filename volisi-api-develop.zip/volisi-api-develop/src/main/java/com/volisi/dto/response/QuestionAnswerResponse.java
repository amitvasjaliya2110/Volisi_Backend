package com.volisi.dto.response;

public record QuestionAnswerResponse(String questionOption, boolean correct) {}
