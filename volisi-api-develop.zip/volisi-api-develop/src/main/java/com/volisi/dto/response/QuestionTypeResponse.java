package com.volisi.dto.response;

public record QuestionTypeResponse(String name) {}
