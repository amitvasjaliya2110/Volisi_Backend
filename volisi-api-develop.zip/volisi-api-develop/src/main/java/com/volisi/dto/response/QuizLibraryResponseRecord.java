package com.volisi.dto.response;

public record QuizLibraryResponseRecord(
    String name, String coverImage, String status, Long id, Integer players) {}
