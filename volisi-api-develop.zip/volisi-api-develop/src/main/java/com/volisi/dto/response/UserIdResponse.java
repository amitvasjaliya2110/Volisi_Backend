package com.volisi.dto.response;

public record UserIdResponse(Long id) {}
