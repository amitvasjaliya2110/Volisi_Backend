package com.volisi.dto.response;

public record UserResponse(String username, String email) {}
