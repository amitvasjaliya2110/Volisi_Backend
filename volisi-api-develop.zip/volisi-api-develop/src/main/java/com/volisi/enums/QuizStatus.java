package com.volisi.enums;

public enum QuizStatus {
  CREATED,
  DRAFT
}
