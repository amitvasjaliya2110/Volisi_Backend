package com.volisi.model;

import lombok.Data;

@Data
public class AnswerOptionDto {
  private Long id;
  private String name;
}
