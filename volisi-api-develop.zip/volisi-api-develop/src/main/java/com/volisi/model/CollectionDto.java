package com.volisi.model;

import lombok.Data;

@Data
public class CollectionDto {
  private Long id;
  private String name;
}
