package com.volisi.model;

import lombok.Data;

@Data
public class PlayerDto {
  private Long id;
  private String name;
}
