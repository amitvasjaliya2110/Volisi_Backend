package com.volisi.model;

import lombok.Data;

@Data
public class PointsConfigDto {
  private Long id;
  String name;
  String description;
}
