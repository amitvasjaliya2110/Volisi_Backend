package com.volisi.model;

import lombok.Data;

@Data
public class QuestionTypeDto {

  private Long id;

  private String name;
}
