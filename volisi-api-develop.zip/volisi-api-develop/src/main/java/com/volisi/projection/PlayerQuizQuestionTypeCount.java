package com.volisi.projection;

public interface PlayerQuizQuestionTypeCount {
  String getQuestionTypeName();

  Integer getQuestionCount();
}
