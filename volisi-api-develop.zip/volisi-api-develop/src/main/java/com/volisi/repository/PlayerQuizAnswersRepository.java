package com.volisi.repository;

import com.volisi.entity.PlayerQuizAnswers;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PlayerQuizAnswersRepository extends JpaRepository<PlayerQuizAnswers, Long> {}
