package com.volisi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VolisiApplicationTests {

  @Test
  void contextLoads() {}
}
